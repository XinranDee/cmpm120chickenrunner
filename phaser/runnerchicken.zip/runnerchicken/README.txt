

CONTROLS:
W-A-S-D: movement 
SPACEBAR: boost speed of spaceship  
NUMPAD_1: shoot 

